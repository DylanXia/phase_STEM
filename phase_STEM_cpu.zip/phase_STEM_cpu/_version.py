__all__ = ['__version__']

__version__ = 'cpu_version'
